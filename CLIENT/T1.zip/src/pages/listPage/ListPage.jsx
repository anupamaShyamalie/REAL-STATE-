import { useEffect, useState } from 'react';
import Card from '../../component/card/Card';
import Filter from '../../component/filter/Filter';
import Map from '../../component/map/Map';
import apiRequest from '../../lib/apiRequest';
import './listPage.scss';

const ListPage = () => {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        setLoading(true);
        const response = await apiRequest.get('/posts');
        setPosts(response.data);
      } catch (err) {
        console.error('Error fetching posts:', err);
        setError('Failed to fetch posts. Please try again.');
      } finally {
        setLoading(false);
      }
    };

    fetchPosts();
  }, []);

  if (loading) {
    return (
      <div className='listPage'>
        <div className="listContainer">
          <div className="wrapper">
            <div className="loading">Loading posts...</div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className='listPage'>
        <div className="listContainer">
          <div className="wrapper">
            <div className="error">{error}</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className='listPage'>
      <div className="listContainer">
        <div className="wrapper">
          <Filter/>
          {posts.length > 0 ? (
            posts.map(item => (
              <Card key={item.id} item={item}/>
            ))
          ) : (
            <div className="no-posts">No posts available</div>
          )}
        </div>
      </div>
      <div className="mapContainer">
        <Map items={posts} />
      </div>
    </div>
  );
};

export default ListPage;